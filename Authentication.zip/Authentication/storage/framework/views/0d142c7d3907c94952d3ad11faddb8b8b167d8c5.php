<?php $__env->startSection('main'); ?>
<div id="body">
    <div id="featured">
        <img src="<?php echo e(url('/')); ?>/new/images/the-beacon.jpg" alt="">
        <div>
            <h2>the beacon to all mankind</h2>
            <span>Our website templates are created with</span>
            <span>inspiration, checked for quality and originality</span>
            <span>and meticulously sliced and coded.</span>
            <a href="blog-single-post.html" class="more">read more</a>
        </div>
    </div>
    <ul>
        <li>
            <a href="gallery.html">
                <img src="<?php echo e(url('/')); ?>/new/images/the-father.jpg" alt="">
                <span>the father</span>
            </a>
        </li>
        <li>
            <a href="gallery.html">
                <img src="<?php echo e(url('/')); ?>/new/images/the-actor.jpg" alt="">
                <span>the actor</span>
            </a>
        </li>
        <li>
            <a href="gallery.html">
                <img src="<?php echo e(url('/')); ?>/new/images/the-nerd.jpg" alt="">
                <span>the nerd</span>
            </a>
        </li>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tey\resources\views/page.blade.php ENDPATH**/ ?>