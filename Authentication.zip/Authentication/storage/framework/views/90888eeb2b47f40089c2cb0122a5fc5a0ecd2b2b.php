<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Authentication</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/new/css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/new/css/mobile.css" media="screen and (max-width : 568px)">
	<script type="text/javascript" src="<?php echo e(url('/')); ?>/new/js/mobile.js"></script>

</head>
<body>
<div id="header">


	<a href="index.html" class="logo">
		<img src="<?php echo e(url('/')); ?>/new/images/logo.jpg" alt="">
	</a>

	<ul id="navigation">
		<li class="selected">
			<a href="<?php echo e(url('/')); ?>">home</a>
		</li>
		<li>
			<a href="<?php echo e(url('/projectdemo')); ?>">project</a>
		</li>
		<li>
			<a href="<?php echo e(url('/about')); ?>">contact</a>
		</li>
		<?php if(Auth::guest()): ?>
			<li><a href="<?php echo e(route('login')); ?>">Login</a></li>
			<li><a href="<?php echo e(route('register')); ?>">Register</a></li>
		<?php else: ?>
			<li >
				<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
					<?php echo e(Auth::user()->name); ?> <span class="caret"></span>
				</a>

				<ul class="dropdown-menu" role="menu">
					<li>
						<a href="<?php echo e(route('logout')); ?>"
						   onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();">
							Logout
						</a>

						<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
							<?php echo e(csrf_field()); ?>

						</form>
					</li>
				</ul>
			</li>
		<?php endif; ?>

	</ul>

</div>
<?php /**PATH C:\xampp\htdocs\tey\resources\views/header.blade.php ENDPATH**/ ?>