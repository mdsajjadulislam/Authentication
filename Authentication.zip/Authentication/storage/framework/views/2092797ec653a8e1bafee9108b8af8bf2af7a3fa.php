<?php $__env->startSection('main'); ?>
    <div class="navbar">

        <h1>NID SYSTEM(C programming)</h1>
        <h1>BlOOD DONATE(JAVA programming and oop)</h1>
        <h1>PERSONAL SITE(Laravel framwork)</h1>
        <h1>GAIN.COM(.net)</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tey\resources\views/projectdemo.blade.php ENDPATH**/ ?>