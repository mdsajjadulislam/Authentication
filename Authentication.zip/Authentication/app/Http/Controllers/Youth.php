<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;



use DB;
use Auth;

class Youth extends Controller
{
    public function index(){
        return view('page');
    }

    public function login(){
        return view('auth.login');
    }
    public function about(){
        return view('about');
    }
    public function project1(){
        return view('projectdemo');
    }
    public function account(){
        $pass = DB::table('users')->select('users.*')->where('users.id','=',Auth::user()->id)->first();


        $encrypt = $pass->password;
        $message   = Crypt::decrypt($pass->password);


        return view('account',compact('message','encrypt'));

    }

}
