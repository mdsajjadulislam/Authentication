@extends('master')

@section('main')
    <div class="navbar">

        <h1>NID SYSTEM(C programming)</h1>
        <h1>BlOOD DONATE(JAVA programming and oop)</h1>
        <h1>PERSONAL SITE(Laravel framwork)</h1>
        <h1>GAIN.COM(.net)</h1>
    </div>
@endsection
