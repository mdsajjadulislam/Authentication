
@extends('master')

@section('main')
    <div class="navbar">

       <h1>Name:Md.Sajjadul islam</h1>
        <h1>Email:bappi1998.swe@gmail.com</h1>
        <h1>Phone:+8801798714381</h1>

    </div>
@endsection